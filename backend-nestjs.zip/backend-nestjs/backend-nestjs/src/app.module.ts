import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import {ConfigModule} from "@nestjs/config";
import {SerieModule} from "./series/serie.module";
import 'dotenv/config'
import {MongooseModule} from "@nestjs/mongoose";
import * as process from "process";
@Module({
    imports: [
        ConfigModule.forRoot(),
        MongooseModule.forRoot(process.env.URL as string),
        SerieModule,

    ],
    controllers: [AppController],

    providers: [AppService],
})
export class AppModule {}
