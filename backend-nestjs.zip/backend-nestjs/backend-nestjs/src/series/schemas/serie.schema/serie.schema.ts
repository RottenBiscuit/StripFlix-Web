import {Schema} from "mongoose";

export const serieSchema = new Schema({
    title: { type: String, required: true },
    emision_date: {type: Date,default: new Date().getFullYear()},
    images: [{type: String, required: true}],
    categories: [{type: String, required: true}],
    sinopsis: {type: String, required: true},
    chapters: {type: Number, required: true}
}, {versionKey: false})