import { Module } from '@nestjs/common';
import { SerieController } from './serie.controller';
import { SerieService } from './services/series/serie.service';
import {MongooseModule} from "@nestjs/mongoose";
import {serieSchema} from "./schemas/serie.schema/serie.schema";

@Module({
  imports: [MongooseModule.forFeature(
    [{
      name: 'Serie',
      schema: serieSchema,
      collection: 'series'
    }]
  )],
  controllers: [SerieController],
  providers: [SerieService]
})
export class SerieModule {}
