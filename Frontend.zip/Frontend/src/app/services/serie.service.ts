import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {
  ApiResponseMessage,
  ApiResponseSerie,
  ApiResponseSerieCategories,
  ApiResponseSeries,
  Serie
} from "../common/serie";
import {environment} from "../enviroments/environment";


@Injectable({
  providedIn: 'root'
})
export class SerieService {
  private readonly http: HttpClient = inject(HttpClient);
  constructor() { }
  getSerieList(): Observable<ApiResponseSeries>{
    return this.http.get<ApiResponseSeries>(environment.apiUrl);
  }
  getSerie(id:String): Observable<ApiResponseSerie>{
    return this.http.get<ApiResponseSerie>(environment.apiUrl+ '/:' + id);
  }
  getCategories(): Observable<ApiResponseSerieCategories>{
    return this.http.get<ApiResponseSerieCategories>(environment.apiUrl + '/categories');
  }
  addSerie(serie: Serie): Observable<ApiResponseMessage>{
    return this.http.post<ApiResponseMessage>(environment.apiUrl, serie);
  }
  updateSerie(serie: Serie): Observable<ApiResponseMessage>{
    return this.http.put<ApiResponseMessage>( environment.apiUrl+'/'+ serie._id ,serie);
  }
  deleteSerie(id: String): Observable<ApiResponseMessage>{
    return this.http.delete<ApiResponseMessage>('http://localhost:4000/api/v1/series/series/' + id);
  }
}
