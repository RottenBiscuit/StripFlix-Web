export interface ApiResponseSeries {
  status: string
  data: Serie[]
}
export interface ApiResponseSerie {
  status: string
  data: Serie
}
export interface ApiResponseSerieCategories {
  status: string
  data: string[]
}
export interface ApiResponseMessage {
  status: string
  data: string
}

export interface Serie {
  _id: string
  title: string
  emision_date: Date
  images: string[]
  categories: string[]
  sinopsis: string
  chapters: number
}
