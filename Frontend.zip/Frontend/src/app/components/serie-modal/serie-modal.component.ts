import {Component, inject, Input, OnInit} from '@angular/core';
import {Serie} from "../../common/serie";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";
import {SerieService} from "../../services/serie.service";
import {FormBuilder, FormControl, FormGroup, ReactiveFormsModule} from "@angular/forms";
import {FaIconComponent} from "@fortawesome/angular-fontawesome";
import {faPlusCircle} from "@fortawesome/free-solid-svg-icons";

@Component({
  selector: 'app-serie-modal',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    FaIconComponent
  ],
  templateUrl: './serie-modal.component.html',
  styleUrl: './serie-modal.component.css'
})
export class SerieModalComponent implements OnInit {
  @Input() serie!: Serie;
  @Input()({required: true}) editar!: boolean;

  @Input()({required: true}) categories!: string[];

  activeModal: NgbActiveModal = inject(NgbActiveModal);
  private readonly serieService: SerieService = inject(SerieService);
  private readonly formBuilder: FormBuilder = inject(FormBuilder);

  formSerie: FormGroup = this.formBuilder.group({
    _id: [''],
    title: [''],
    emision_date: [],
    images: [],
    categories: [],
    sinopsis: [''],
    chapters: [''],
  });
  ngOnInit(): void {
    this.loadCategories();
    if (this.editar) {
      this.formSerie.setValue(this.serie);
      console.log('Serie data loaded')
    } else {
      this.formSerie.reset();
    }
  }


  myNewCategorie: FormGroup = this.formBuilder.group({newCategorie: ['']});


  loadCategories() {
    this.serieService.getCategories().subscribe({
      next: value => {
        console.log('Categorías recibidas:', value.data);
        this.categories = value.data;
      },
      error: err => console.error(err.message),
    });
  }

  get title() {
    return this.formSerie.get('title');
  }

  get emision_date() {
    return this.formSerie.get('emision_date');
  }

  get images() {
    return this.formSerie.get('images');

  }

  get categoriesF(): any {
    return this.formSerie.get('categories');
  }

  get sinopsis() {
    return this.formSerie.get('sinopsis');
  }

  get chapters() {
    return this.formSerie.get('chapters');
  }

  get newCategorie() {
    return this.myNewCategorie.get('newCategorie');
  }

  addNewCategorie(newCategorie: any) {
    console.log(this.editar)
    if (!this.editar) {
      this.categories.push(newCategorie);
    } else {
      let newCat;
      newCat = this.categoriesF.value;
      newCat.push(newCategorie);
      console.log('pushed categorie :D')
      this.formSerie.setControl(
        'categories', new FormControl(newCat)
      )
      this.categories.push(newCategorie);
      console.log('added categorie :D')
    }

    this.myNewCategorie.reset();
  }

  onSubmit() {
    if (this.editar) {
      this.serieService.updateSerie(this.formSerie.getRawValue()).subscribe({
        next: value => console.log(value),
        complete: () => {
          console.log('Serie actualizada');
          this.activeModal.dismiss();
        },
        error: err => console.error(err)
      });
    } else {
      this.serieService.addSerie(this.formSerie.getRawValue()).subscribe({
        next: value => console.log(value),
        complete: () => {
          console.log('Serie agregada');
          this.activeModal.dismiss();
        },
        error: err => console.error(err)
      });
    }
  }

  protected readonly faPlusCircle = faPlusCircle;
}
