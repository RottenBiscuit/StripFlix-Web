import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SerieModalComponent } from './serie-modal.component';

describe('AddModalComponent', () => {
  let component: SerieModalComponent;
  let fixture: ComponentFixture<SerieModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SerieModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SerieModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
