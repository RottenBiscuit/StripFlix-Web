import {Component, inject} from '@angular/core';
import {NgOptimizedImage} from "@angular/common";
import {RouterLink, RouterLinkActive} from "@angular/router";
import {Serie} from "../../common/serie";
import {MatDialog} from "@angular/material/dialog";
import {SerieService} from "../../services/serie.service";
import {NgbModal} from "@ng-bootstrap/ng-bootstrap";
import {SerieModalComponent} from "../serie-modal/serie-modal.component";

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    NgOptimizedImage,
    RouterLink,
    RouterLinkActive,
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  series: Serie[] = [];
  private readonly serieService: SerieService = inject(SerieService);
  categories: string[] = [];
  private readonly modalService: NgbModal = inject(NgbModal);

  constructor(private dialog: MatDialog) {
    this.loadSeries();
  }

  private loadSeries() {
    this.serieService.getSerieList().subscribe({
      next: value => {
        this.series = value.data;
      },
      error: err => console.error(err.message),
      complete: () => {

      },
    });

    this.serieService.getCategories().subscribe({
      next: value => (this.categories = value.data),
      error: err => console.error(err.message),
    });
  }
  crearSerie(){
    const modalRef = this.modalService.open(SerieModalComponent);
    modalRef.componentInstance.editar = false;
    modalRef.componentInstance.categories = this.categories;
    modalRef.result.then(() =>{this.loadSeries();}).catch(() => {this.loadSeries()});
  }
}
