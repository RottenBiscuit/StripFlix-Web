import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { SerieService } from '../../services/serie.service';
import { Serie } from '../../common/serie';
import {NgbCarousel, NgbSlide} from "@ng-bootstrap/ng-bootstrap";
import { MatDialog } from '@angular/material/dialog';
import { PopUpComponent } from '../../components/pop-up/pop-up.component';
import {HeaderComponent} from "../../components/header/header.component";
import {SeriesInfoComponent} from "../serieInfo/series-info.component";
import {RouterLink} from "@angular/router";
import {Popup2Component} from "../../components/popup2/popup2.component";
import {MatGridList, MatGridTile} from "@angular/material/grid-list";

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, MatCardModule, NgbCarousel, NgbSlide, HeaderComponent, RouterLink, MatGridList, MatGridTile],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  private readonly serieService: SerieService = inject(SerieService);
  showpopup: boolean = false;
  series: Serie[] = [];
  categories: string[] = [];

  constructor(private dialog: MatDialog) {
    this.loadSeries();
  }

  private loadSeries() {
    this.serieService.getSerieList().subscribe({
      next: value => {
        this.series = value.data;
      },
      error: err => console.error(err.message),
      complete: () => {
        //this.showRandomPopup(1);
        //this.showRandomPopup(2);
      },
    });

    this.serieService.getCategories().subscribe({
      next: value => (this.categories = value.data),
      error: err => console.error(err.message),
    });
  }

  showRandomPopup(num: number) {
    const randomTime1 = Math.floor(Math.random() * (4000 - 1000 + 1)) + 1000;
    const randomTime2 = randomTime1+ Math.floor(Math.random() * (5000 - 1000 + 1)) + 1000;
    if (num==1){
      setTimeout(() => {
        this.dialog.open(PopUpComponent);
      }, randomTime1);
    }else {
      setTimeout(() => {
        this.dialog.open(Popup2Component);
      }, randomTime2);
    }
    }


  protected readonly SeriesInfoComponent = SeriesInfoComponent;
}
