import {Component, inject, OnInit} from '@angular/core';
import {ActivatedRoute, RouterLink} from '@angular/router';
import {SerieService} from "../../services/serie.service";
import {Serie} from "../../common/serie";
import {HeaderComponent} from "../../components/header/header.component";
import {DatePipe, NgForOf, NgIf} from "@angular/common";
import {MatCard, MatCardContent, MatCardTitle} from "@angular/material/card";
import {NgbCarousel, NgbModal, NgbModalModule, NgbSlide} from "@ng-bootstrap/ng-bootstrap";
import {MatIcon} from "@angular/material/icon";
import { Router } from '@angular/router';
import {SerieModalComponent} from "../../components/serie-modal/serie-modal.component";

@Component({
  selector: 'app-series-info',
  templateUrl: './series-info.component.html',
  standalone: true,
  imports: [
    HeaderComponent,
    MatCard,
    MatCardTitle,
    NgbCarousel,
    NgbSlide,
    MatIcon,
    NgbModalModule,
    DatePipe,

  ],
  styleUrls: ['./series-info.component.css']
})
export class SeriesInfoComponent implements OnInit {
  private readonly modalService: NgbModal = inject(NgbModal);
  serie: Serie = { _id: '', title: '', emision_date: new Date(), images: [], categories: [], sinopsis: '', chapters: 0 };

  constructor(
    private serieService: SerieService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
   this.loadSeries()
  }
  loadSeries(){
    const id = this.route.snapshot.paramMap.get('id');
    console.log('ID de la serie:', id);
    if (id) {
      this.serieService.getSerieList().subscribe((response: { data: any[] }) => {
        const serieEncontrada = response.data.find((serie: Serie) => serie._id === id);
        if (serieEncontrada) {
          this.serie = serieEncontrada;
          console.log('Serie cargada:', this.serie);
        } else {
          console.error('Serie no encontrada');
        }
      });
    }
  }

  eliminarSerie(serie: Serie) {

    this.serieService.deleteSerie(serie._id).subscribe({
      next: (value) => {
        console.log('Serie eliminada correctamente:', value);
        this.router.navigate(['']).then(() => {
          window.location.reload();
        });
      },
      error: (err) => {
        console.error('Error al eliminar la serie:', err);
      }
    });
  }
  editarSerie(serie: Serie) {
      const modalRef = this.modalService.open(SerieModalComponent);
    modalRef.componentInstance.serie = serie;
    modalRef.componentInstance.editar = true;
    modalRef.componentInstance.categories = this.serie.categories;
      modalRef.result.then(() =>{this.loadSeries();}).catch(() => {this.loadSeries()});
  }

}
